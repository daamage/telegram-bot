import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TOKEN = os.getenv("TOKEN")

def start(update: Update, context: CallbackContext):
    keyboard = [[InlineKeyboardButton("💳 Оплатити онлайн", url="https://your-payment-link.com")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text("Привіт! Оберіть опцію нижче:", reply_markup=reply_markup)

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
